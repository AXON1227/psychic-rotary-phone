from __future__ import annotations

import argparse
import json
import os
import shutil
import subprocess
import time
import zipfile
from datetime import datetime
from pathlib import Path, PurePosixPath


PROTECTED_TOP_LEVEL = {".venv", "data", "logs", "screenshots", "browser-profile"}


def wait_for_exit(pid: int, timeout: float = 30.0) -> None:
    deadline = time.time() + timeout
    while time.time() < deadline:
        try:
            os.kill(pid, 0)
        except OSError:
            return
        time.sleep(0.3)


def safe_members(archive: zipfile.ZipFile) -> list[zipfile.ZipInfo]:
    selected: list[zipfile.ZipInfo] = []
    for item in archive.infolist():
        path = PurePosixPath(item.filename)
        if item.is_dir():
            continue
        if path.is_absolute() or ".." in path.parts or not path.parts:
            raise ValueError(f"Unsafe update path: {item.filename}")
        if path.parts[0] in PROTECTED_TOP_LEVEL:
            raise ValueError(f"Protected update path: {item.filename}")
        selected.append(item)
    if not selected:
        raise ValueError("The update package is empty")
    return selected


def install(package: Path, target: Path, version: str) -> None:
    local_data = Path(os.getenv("LOCALAPPDATA") or target / "data") / "SeunghyunPCAgent"
    backup = local_data / "update-backups" / f"before-{version}-{datetime.now():%Y%m%d_%H%M%S}"
    staging = local_data / "update-staging" / version
    log_path = local_data / "update.log"
    backup.mkdir(parents=True, exist_ok=True)
    staging.mkdir(parents=True, exist_ok=True)
    installed: list[Path] = []
    originals: list[tuple[Path, Path]] = []
    try:
        with zipfile.ZipFile(package) as archive:
            members = safe_members(archive)
            for item in members:
                archive.extract(item, staging)
        for source in sorted(staging.rglob("*")):
            if not source.is_file():
                continue
            relative = source.relative_to(staging)
            destination = target / relative
            if destination.exists():
                saved = backup / relative
                saved.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(destination, saved)
                originals.append((saved, destination))
            destination.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(source, destination)
            installed.append(destination)
        log_path.parent.mkdir(parents=True, exist_ok=True)
        with log_path.open("a", encoding="utf-8") as log:
            log.write(json.dumps({"time": datetime.now().isoformat(), "status": "installed", "version": version}, ensure_ascii=False) + "\n")
    except Exception as exc:
        for destination in reversed(installed):
            destination.unlink(missing_ok=True)
        for saved, destination in reversed(originals):
            destination.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(saved, destination)
        log_path.parent.mkdir(parents=True, exist_ok=True)
        with log_path.open("a", encoding="utf-8") as log:
            log.write(json.dumps({"time": datetime.now().isoformat(), "status": "rolled_back", "version": version, "error": repr(exc)}, ensure_ascii=False) + "\n")
        raise
    finally:
        shutil.rmtree(staging, ignore_errors=True)


def restart(target: Path) -> None:
    launcher = target / "RUN_AGENT.cmd"
    if os.name == "nt":
        subprocess.Popen(["cmd.exe", "/c", "start", "", str(launcher)], cwd=str(target))
    else:
        subprocess.Popen([str(launcher)], cwd=str(target))


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--package", required=True, type=Path)
    parser.add_argument("--target", required=True, type=Path)
    parser.add_argument("--version", required=True)
    parser.add_argument("--pid", required=True, type=int)
    args = parser.parse_args()
    wait_for_exit(args.pid)
    install(args.package.resolve(), args.target.resolve(), args.version)
    restart(args.target.resolve())


if __name__ == "__main__":
    main()
