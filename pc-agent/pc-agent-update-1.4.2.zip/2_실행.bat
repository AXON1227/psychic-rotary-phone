@echo off
chcp 65001 >nul
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
  echo 먼저 1_설치.bat을 실행하세요.
  pause
  exit /b 1
)
".venv\Scripts\python.exe" -c "import jwt, cryptography" >nul 2>nul
if errorlevel 1 (
  echo ChatGPT 로그인 업데이트 구성요소를 설치합니다...
  ".venv\Scripts\python.exe" -m pip install -r requirements.txt
  if errorlevel 1 (
    echo 업데이트 구성요소 설치에 실패했습니다. 이 화면을 보여주세요.
    pause
    exit /b 1
  )
)
start "Seunghyun PC Agent" ".venv\Scripts\pythonw.exe" app.py

