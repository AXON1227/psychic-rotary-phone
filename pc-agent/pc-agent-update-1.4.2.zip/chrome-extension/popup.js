chrome.runtime.sendMessage({type: "wake-pc-agent"}).catch(() => {});

async function checkConnection() {
  const headers = {"X-PC-Agent": "chrome-extension-1"};
  for (let port = 18765; port < 18775; port += 1) {
    try {
      const response = await fetch(`http://127.0.0.1:${port}/ping`, {headers});
      if (response.ok && (await response.json())?.ok) {
        const status = document.getElementById("status");
        status.textContent = "● 일반 Chrome 연결됨";
        status.className = "ok";
        return;
      }
    } catch (_error) {}
  }
  const status = document.getElementById("status");
  status.textContent = "● PC Agent를 먼저 실행하세요";
  status.className = "bad";
}

checkConnection();
