from __future__ import annotations

import hashlib
import json
import os
import re
import subprocess
import sys
import urllib.request
from dataclasses import dataclass
from pathlib import Path


MAX_UPDATE_BYTES = 50 * 1024 * 1024


def version_tuple(value: str) -> tuple[int, ...]:
    parts = [int(part) for part in re.findall(r"\d+", value)]
    return tuple((parts + [0, 0, 0])[:3])


@dataclass(frozen=True)
class UpdateInfo:
    version: str
    download_url: str
    sha256: str
    notes: str = ""


class UpdateClient:
    def __init__(self, feed_url: str, current_version: str, data_dir: Path) -> None:
        self.feed_url = feed_url
        self.current_version = current_version
        self.update_dir = data_dir / "updates"
        self.update_dir.mkdir(parents=True, exist_ok=True)

    @staticmethod
    def _request(url: str) -> urllib.request.Request:
        if not url.startswith("https://"):
            raise ValueError("업데이트 주소는 HTTPS여야 합니다.")
        return urllib.request.Request(
            url,
            headers={"Accept": "application/json", "User-Agent": "Seunghyun-PC-Agent-Updater/1.0"},
        )

    def check(self) -> UpdateInfo | None:
        with urllib.request.urlopen(self._request(self.feed_url), timeout=12) as response:
            raw = response.read(256_000)
        payload = json.loads(raw.decode("utf-8"))
        version = str(payload.get("version") or "").strip()
        download_url = str(payload.get("download_url") or "").strip()
        digest = str(payload.get("sha256") or "").strip().lower()
        notes = str(payload.get("notes") or "").strip()
        if not version or not download_url.startswith("https://"):
            raise ValueError("업데이트 정보가 올바르지 않습니다.")
        if not re.fullmatch(r"[0-9a-f]{64}", digest):
            raise ValueError("업데이트 검증값이 올바르지 않습니다.")
        if version_tuple(version) <= version_tuple(self.current_version):
            return None
        return UpdateInfo(version=version, download_url=download_url, sha256=digest, notes=notes)

    def download(self, info: UpdateInfo) -> Path:
        destination = self.update_dir / f"pc-agent-{info.version}.zip"
        temporary = destination.with_suffix(".download")
        digest = hashlib.sha256()
        total = 0
        try:
            with urllib.request.urlopen(self._request(info.download_url), timeout=45) as response:
                with temporary.open("wb") as output:
                    while True:
                        chunk = response.read(1024 * 1024)
                        if not chunk:
                            break
                        total += len(chunk)
                        if total > MAX_UPDATE_BYTES:
                            raise ValueError("업데이트 파일이 허용 크기를 초과했습니다.")
                        output.write(chunk)
                        digest.update(chunk)
            if digest.hexdigest().lower() != info.sha256:
                raise ValueError("업데이트 파일 검증에 실패했습니다.")
            os.replace(temporary, destination)
            return destination
        finally:
            if temporary.exists():
                temporary.unlink(missing_ok=True)


def launch_installer(package: Path, target: Path, version: str) -> None:
    updater = target / "updater.py"
    command = [
        sys.executable,
        str(updater),
        "--package",
        str(package),
        "--target",
        str(target),
        "--version",
        version,
        "--pid",
        str(os.getpid()),
    ]
    creationflags = 0
    if os.name == "nt":
        creationflags = subprocess.DETACHED_PROCESS | subprocess.CREATE_NEW_PROCESS_GROUP
    subprocess.Popen(
        command,
        cwd=str(target),
        close_fds=True,
        creationflags=creationflags,
    )

