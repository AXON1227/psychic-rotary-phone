@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title Seunghyun PC Agent

if not exist ".venv\Scripts\pythonw.exe" (
  echo The agent is not installed yet. Running setup first...
  call START_HERE.cmd
  exit /b %errorlevel%
)

if not exist "logs" mkdir "logs"
".venv\Scripts\python.exe" -c "import jwt, cryptography" >nul 2>nul
if errorlevel 1 (
  echo Installing the ChatGPT sign-in update...
  ".venv\Scripts\python.exe" -m pip install -r requirements.txt
  if errorlevel 1 (
    echo The update could not install its required components.
    echo Keep this window open and send a screenshot to ChatGPT.
    pause
    exit /b 1
  )
)
start "Seunghyun PC Agent" ".venv\Scripts\pythonw.exe" "launcher.py"
exit /b 0

