const BRIDGE_PORTS = Array.from({length: 10}, (_, index) => 18765 + index);
const HEADERS = {"X-PC-Agent": "chrome-extension-1"};
let bridge = "";

const delay = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

async function fetchTimed(url, options = {}, timeoutMs = 1800) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    return await fetch(url, {...options, signal: controller.signal});
  } finally {
    clearTimeout(timer);
  }
}

async function findBridge() {
  for (const port of BRIDGE_PORTS) {
    const candidate = `http://127.0.0.1:${port}`;
    try {
      const response = await fetchTimed(`${candidate}/ping`, {headers: HEADERS});
      if (response.ok) {
        const payload = await response.json();
        if (payload?.ok) {
          bridge = candidate;
          return bridge;
        }
      }
    } catch (_error) {}
  }
  bridge = "";
  return "";
}

async function activeTab() {
  const tabs = await chrome.tabs.query({active: true, currentWindow: true});
  if (!tabs.length || !tabs[0].id) throw new Error("활성 Chrome 탭을 찾지 못했습니다.");
  return tabs[0];
}

function collectPage() {
  document.querySelectorAll("[data-pca-id]").forEach((el) => el.removeAttribute("data-pca-id"));
  const selector = [
    "a", "button", "input", "textarea", "select", "summary",
    "[role='button']", "[role='link']", "[role='menuitem']", "[role='tab']", "[role='option']",
    "[contenteditable='true']", "[onclick]", "[aria-controls]", "[aria-expanded]",
    "[tabindex]:not([tabindex='-1'])"
  ].join(",");
  const candidates = [];
  for (const el of Array.from(document.querySelectorAll("body *"))) {
    const rect = el.getBoundingClientRect();
    const style = getComputedStyle(el);
    if (rect.width < 3 || rect.height < 3 || style.visibility === "hidden" || style.display === "none") continue;
    if (Number(style.opacity || 1) < 0.05) continue;
    if (rect.bottom < 0 || rect.right < 0 || rect.top > innerHeight || rect.left > innerWidth) continue;
    const native = el.matches(selector);
    const pointer = style.cursor === "pointer";
    const named = el.hasAttribute("aria-label") || el.hasAttribute("title");
    const icon = Boolean(el.querySelector(":scope > svg, :scope > i, :scope > img")) && rect.width <= 180 && rect.height <= 180;
    if (!native && !pointer && !named && !icon) continue;
    let score = native ? 5 : 0;
    if (named) score += 3;
    if (pointer) score += 2;
    if (icon) score += 2;
    if (el.hasAttribute("aria-expanded") || el.hasAttribute("aria-controls")) score += 3;
    const hint = `${el.id || ""} ${typeof el.className === "string" ? el.className : ""} ${el.getAttribute("aria-label") || ""}`.toLowerCase();
    if (/menu|nav|hamburger|drawer|gnb|toggle|more/.test(hint)) score += 4;
    if (icon && rect.top < 180 && rect.left > innerWidth * 0.6) score += 3;
    candidates.push({el, rect, style, score});
  }
  candidates.sort((a, b) => b.score - a.score || a.rect.top - b.rect.top || a.rect.left - b.rect.left);
  return candidates.slice(0, 180).map(({el, rect, style}, index) => {
    const id = `pca-${index}`;
    el.setAttribute("data-pca-id", id);
    const type = (el.getAttribute("type") || "").toLowerCase();
    const className = typeof el.className === "string" ? el.className : "";
    return {
      id,
      tag: el.tagName.toLowerCase(),
      type,
      text: (el.innerText || el.getAttribute("aria-label") || el.getAttribute("title") || "").trim().slice(0, 160),
      label: el.labels ? Array.from(el.labels).map((x) => x.innerText.trim()).join(" | ").slice(0, 160) : "",
      name: (el.getAttribute("name") || "").slice(0, 80),
      placeholder: (el.getAttribute("placeholder") || "").slice(0, 120),
      href: el.tagName === "A" ? (el.href || "").slice(0, 300) : "",
      ariaLabel: (el.getAttribute("aria-label") || "").slice(0, 120),
      ariaExpanded: el.getAttribute("aria-expanded") || "",
      ariaControls: (el.getAttribute("aria-controls") || "").slice(0, 100),
      title: (el.getAttribute("title") || "").slice(0, 120),
      domId: (el.id || "").slice(0, 100),
      classHint: className.slice(0, 140),
      cursor: style.cursor,
      x: Math.round(rect.left), y: Math.round(rect.top),
      width: Math.round(rect.width), height: Math.round(rect.height),
      checked: type === "checkbox" || type === "radio" ? Boolean(el.checked) : undefined
    };
  });
}

function performDomAction(command) {
  const el = document.querySelector(`[data-pca-id="${command.element_id}"]`);
  if (!el) throw new Error("대상 요소가 화면에서 사라졌습니다.");
  el.scrollIntoView({block: "center", inline: "center"});
  if (command.action === "click") {
    el.click();
  } else if (command.action === "hover") {
    for (const name of ["pointerover", "mouseover", "mouseenter"]) {
      el.dispatchEvent(new MouseEvent(name, {bubbles: true, cancelable: true, view: window}));
    }
  } else if (command.action === "fill") {
    el.focus();
    if (el.isContentEditable) {
      el.textContent = command.value || "";
    } else {
      const proto = el.tagName === "TEXTAREA" ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
      const setter = Object.getOwnPropertyDescriptor(proto, "value")?.set;
      if (setter) setter.call(el, command.value || ""); else el.value = command.value || "";
    }
    el.dispatchEvent(new InputEvent("input", {bubbles: true, inputType: "insertText", data: command.value || ""}));
    el.dispatchEvent(new Event("change", {bubbles: true}));
  } else if (command.action === "select") {
    const wanted = String(command.value || "");
    const option = Array.from(el.options || []).find((x) => x.value === wanted || x.text.trim() === wanted);
    if (!option) throw new Error("선택 항목을 찾지 못했습니다.");
    el.value = option.value;
    el.dispatchEvent(new Event("input", {bubbles: true}));
    el.dispatchEvent(new Event("change", {bubbles: true}));
  } else if (command.action === "press") {
    const key = command.value || "Enter";
    el.focus();
    el.dispatchEvent(new KeyboardEvent("keydown", {key, code: key, bubbles: true}));
    el.dispatchEvent(new KeyboardEvent("keyup", {key, code: key, bubbles: true}));
    if (key === "Enter" && el.form) el.form.requestSubmit();
  } else {
    throw new Error("지원하지 않는 DOM 작업입니다.");
  }
  return {url: location.href, title: document.title};
}

function visualAction(command) {
  if (command.action === "scroll") {
    window.scrollBy({top: Number(command.value || 650), behavior: "instant"});
    return {url: location.href};
  }
  const x = Number(command.x || 0) * innerWidth / Math.max(Number(command.image_width || innerWidth), 1);
  const y = Number(command.y || 0) * innerHeight / Math.max(Number(command.image_height || innerHeight), 1);
  const el = document.elementFromPoint(x, y);
  if (!el) throw new Error("화면 좌표에서 대상을 찾지 못했습니다.");
  el.click();
  return {url: location.href};
}

function debuggerCall(target, method, params = {}) {
  return new Promise((resolve, reject) => {
    chrome.debugger.sendCommand(target, method, params, (result) => {
      if (chrome.runtime.lastError) reject(new Error(chrome.runtime.lastError.message));
      else resolve(result || {});
    });
  });
}

async function uploadFile(tabId, command) {
  const target = {tabId};
  await chrome.debugger.attach(target, "1.3");
  try {
    const expression = `document.querySelector(${JSON.stringify(`[data-pca-id="${command.element_id}"]`)})`;
    const evaluated = await debuggerCall(target, "Runtime.evaluate", {expression, objectGroup: "pc-agent"});
    const objectId = evaluated.result?.objectId;
    if (!objectId) throw new Error("파일 입력칸을 찾지 못했습니다.");
    const node = await debuggerCall(target, "DOM.requestNode", {objectId});
    await debuggerCall(target, "DOM.setFileInputFiles", {files: [command.value], nodeId: node.nodeId});
    return {uploaded: true};
  } finally {
    await chrome.debugger.detach(target).catch(() => {});
  }
}

async function execute(command) {
  const tab = await activeTab();
  if (command.type === "navigate") {
    const url = String(command.url || "");
    if (!(url.startsWith("https://") || url === "about:blank")) throw new Error("안전하지 않은 주소입니다.");
    await chrome.tabs.update(tab.id, {url});
    return {url};
  }
  if (command.type === "observe") {
    const injected = await chrome.scripting.executeScript({target: {tabId: tab.id}, func: collectPage});
    return {url: tab.url || "", title: tab.title || "", elements: injected[0]?.result || []};
  }
  if (command.type === "screenshot") {
    const imageUrl = await chrome.tabs.captureVisibleTab(tab.windowId, {format: "jpeg", quality: 72});
    const dims = await chrome.scripting.executeScript({target: {tabId: tab.id}, func: () => ({width: innerWidth, height: innerHeight})});
    return {image_url: imageUrl, width: dims[0]?.result?.width || 1, height: dims[0]?.result?.height || 1};
  }
  if (command.type === "act") {
    if (command.action === "navigate") {
      const url = String(command.url || "");
      if (!url.startsWith("https://")) throw new Error("안전하지 않은 주소입니다.");
      await chrome.tabs.update(tab.id, {url});
      return {url};
    }
    if (command.action === "upload") return await uploadFile(tab.id, command);
    const func = command.action === "visual_click" || command.action === "scroll" ? visualAction : performDomAction;
    const injected = await chrome.scripting.executeScript({target: {tabId: tab.id}, func, args: [command]});
    return injected[0]?.result || {};
  }
  throw new Error("알 수 없는 PC Agent 명령입니다.");
}

async function sendResult(id, ok, data, error) {
  if (!bridge) throw new Error("PC Agent bridge not found");
  await fetch(`${bridge}/result`, {
    method: "POST",
    headers: {...HEADERS, "Content-Type": "application/json"},
    body: JSON.stringify({id, ok, data: data || {}, error: error || ""})
  });
}

let polling = false;

async function pollingBurst() {
  if (polling) return;
  polling = true;
  try {
    // Keep accepting consecutive agent steps. Chrome may suspend the service
    // worker later; the alarm/startup hooks recreate this loop automatically.
    while (true) {
      try {
        if (!bridge && !(await findBridge())) {
          await delay(1000);
          continue;
        }
        const response = await fetch(`${bridge}/next`, {headers: HEADERS});
        if (response.status === 200) {
          const command = await response.json();
          try {
            const data = await execute(command);
            await sendResult(command.id, true, data, "");
          } catch (error) {
            await sendResult(command.id, false, {}, String(error?.message || error));
          }
        } else if (response.status !== 204) {
          await delay(1000);
        }
      } catch (_error) {
        bridge = "";
        await delay(1000);
      }
    }
  } finally {
    polling = false;
  }
}

chrome.runtime.onInstalled.addListener(() => {
  chrome.alarms.create("pc-agent-poll", {periodInMinutes: 0.5});
  pollingBurst();
});

chrome.runtime.onStartup.addListener(() => {
  chrome.alarms.create("pc-agent-poll", {periodInMinutes: 0.5});
  pollingBurst();
});

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === "pc-agent-poll") pollingBurst();
});

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message?.type === "wake-pc-agent") {
    pollingBurst();
    sendResponse({ok: true});
  }
});

chrome.alarms.create("pc-agent-poll", {periodInMinutes: 0.5});
pollingBurst();
