from __future__ import annotations

import json
import base64
import io
import os
import platform
import queue
import re
import shutil
import subprocess
import sys
import threading
import time
import uuid
import webbrowser
from datetime import datetime
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from types import SimpleNamespace
import tkinter as tk
from tkinter import messagebox, scrolledtext, simpledialog, ttk

import pyautogui
import pyperclip
import keyring
from openai import OpenAI
from PIL import Image, ImageGrab
from pynput import keyboard
from playwright.sync_api import sync_playwright

from chatgpt_plan import ChatGPTPlanAuth, PlanAuthError
from auto_update import UpdateClient, UpdateInfo, launch_installer


ROOT = Path(__file__).resolve().parent
WINDOWS_DATA = os.getenv("LOCALAPPDATA")
DATA = Path(WINDOWS_DATA) / "SeunghyunPCAgent" if WINDOWS_DATA else ROOT / "data"
LOGS = ROOT / "logs"
SHOTS = ROOT / "screenshots"
PROFILE = DATA / "chrome-profile"
KEYRING_SERVICE = "SeunghyunPCAgent"
KEYRING_USER = "openai_api_key"
USAGE_FILE = DATA / "api_usage.json"
SETTINGS_FILE = DATA / "settings.json"
TASK_FILE = DATA / "last_task.json"
DOWNLOADS = DATA / "downloads"
CHROME_EXTENSION = ROOT / "chrome-extension"
BRIDGE_PORT = 18765
BRIDGE_PORT_ATTEMPTS = 10
APP_VERSION = "1.4.0"
UPDATE_FEED_URL = "https://raw.githubusercontent.com/AXON1227/psychic-rotary-phone/main/pc-agent/latest.json"
MODEL_OPTIONS = {
    "절약형 · GPT-6 Luna": "gpt-6-luna",
    "고성능 · GPT-6.1 Sol": "gpt-6.1-sol",
}
MODEL_PRICES = {
    "gpt-6-luna": {"input": 0.10, "output": 0.50},
    "gpt-6.1-sol": {"input": 2.00, "output": 10.00},
}
for folder in (DATA, LOGS, SHOTS, PROFILE, DOWNLOADS):
    folder.mkdir(parents=True, exist_ok=True)

STOP_EVENT = threading.Event()
pyautogui.FAILSAFE = True
pyautogui.PAUSE = 0.15


def timestamp() -> str:
    return datetime.now().strftime("%Y%m%d_%H%M%S")


def write_log(event: str, **details) -> None:
    record = {"time": datetime.now().isoformat(timespec="seconds"), "event": event, **details}
    with (LOGS / "agent.jsonl").open("a", encoding="utf-8") as f:
        f.write(json.dumps(record, ensure_ascii=False) + "\n")


def find_chrome() -> str | None:
    candidates = [
        shutil.which("chrome"),
        shutil.which("chrome.exe"),
        os.path.expandvars(r"%ProgramFiles%\Google\Chrome\Application\chrome.exe"),
        os.path.expandvars(r"%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe"),
        os.path.expandvars(r"%LocalAppData%\Google\Chrome\Application\chrome.exe"),
    ]
    return next((p for p in candidates if p and Path(p).exists()), None)


class ChromeExtensionBridge:
    def __init__(self, port: int = BRIDGE_PORT) -> None:
        self.port = port
        self.commands: queue.Queue[dict] = queue.Queue()
        self.waiting: dict[str, dict] = {}
        self.lock = threading.Lock()
        self.last_seen = 0.0
        self.server: ThreadingHTTPServer | None = None

    def start(self) -> None:
        bridge = self

        class Handler(BaseHTTPRequestHandler):
            def log_message(self, _format, *_args) -> None:
                return

            def _authorized(self) -> bool:
                return self.headers.get("X-PC-Agent") == "chrome-extension-1"

            def _cors(self) -> None:
                origin = self.headers.get("Origin", "")
                allowed = origin if origin.startswith("chrome-extension://") else "null"
                self.send_header("Access-Control-Allow-Origin", allowed)
                self.send_header("Vary", "Origin")
                self.send_header("Access-Control-Allow-Headers", "Content-Type, X-PC-Agent")
                self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")

            def _json(self, status: int, payload: dict) -> None:
                body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
                self.send_response(status)
                self._cors()
                self.send_header("Content-Type", "application/json; charset=utf-8")
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)

            def do_OPTIONS(self) -> None:
                self.send_response(204)
                self._cors()
                self.end_headers()

            def do_GET(self) -> None:
                if not self._authorized():
                    self._json(403, {"error": "forbidden"})
                    return
                bridge.last_seen = time.time()
                if self.path == "/ping":
                    self._json(200, {"ok": True, "version": APP_VERSION, "port": bridge.port})
                    return
                if self.path != "/next":
                    self._json(404, {"error": "not_found"})
                    return
                try:
                    command = bridge.commands.get(timeout=15)
                except queue.Empty:
                    self.send_response(204)
                    self._cors()
                    self.end_headers()
                    return
                self._json(200, command)

            def do_POST(self) -> None:
                if not self._authorized() or self.path != "/result":
                    self._json(403, {"error": "forbidden"})
                    return
                bridge.last_seen = time.time()
                try:
                    size = min(int(self.headers.get("Content-Length", "0")), 8_000_000)
                    payload = json.loads(self.rfile.read(size).decode("utf-8"))
                    request_id = str(payload.get("id") or "")
                    with bridge.lock:
                        pending = bridge.waiting.get(request_id)
                        if pending:
                            pending["result"] = payload
                            pending["event"].set()
                    self._json(200, {"ok": True})
                except Exception:
                    self._json(400, {"error": "invalid_result"})

        class ReusableThreadingHTTPServer(ThreadingHTTPServer):
            allow_reuse_address = True

        last_error: OSError | None = None
        for port in range(self.port, self.port + BRIDGE_PORT_ATTEMPTS):
            try:
                self.server = ReusableThreadingHTTPServer(("127.0.0.1", port), Handler)
                self.port = port
                threading.Thread(target=self.server.serve_forever, daemon=True).start()
                write_log("chrome_bridge_started", port=self.port)
                return
            except OSError as exc:
                last_error = exc
        write_log(
            "chrome_bridge_error",
            error_type=type(last_error).__name__ if last_error else "OSError",
            port_start=self.port,
            attempts=BRIDGE_PORT_ATTEMPTS,
        )

    def is_connected(self) -> bool:
        return self.server is not None and time.time() - self.last_seen < 25

    def request(self, command_type: str, timeout: float = 25.0, **payload) -> dict:
        if not self.is_connected():
            raise RuntimeError("Normal Chrome extension is not connected")
        request_id = uuid.uuid4().hex
        pending = {"event": threading.Event(), "result": None}
        with self.lock:
            self.waiting[request_id] = pending
        self.commands.put({"id": request_id, "type": command_type, **payload})
        if not pending["event"].wait(timeout):
            with self.lock:
                self.waiting.pop(request_id, None)
            raise TimeoutError("Normal Chrome extension response timed out")
        with self.lock:
            result = self.waiting.pop(request_id, {}).get("result")
        if not result or not result.get("ok"):
            raise RuntimeError(str((result or {}).get("error") or "Normal Chrome action failed"))
        return dict(result.get("data") or {})


class AgentApp(tk.Tk):
    def __init__(self) -> None:
        super().__init__()
        self.title(f"Seunghyun PC Agent {APP_VERSION}")
        self.geometry("860x690")
        self.minsize(700, 520)
        self.configure(bg="#f4f2ed")
        self.browser_queue: queue.Queue[tuple[str, str]] = queue.Queue()
        self.browser_thread: threading.Thread | None = None
        self.previous_response_id: str | None = None
        self.previous_model: str | None = None
        self.available_models: set[str] | None = None
        self.update_busy = False
        self.plan_auth = ChatGPTPlanAuth(DATA)
        self.update_client = UpdateClient(UPDATE_FEED_URL, APP_VERSION, DATA)
        self.chrome_bridge = ChromeExtensionBridge()
        self.chrome_bridge.start()
        self.monthly_limit_usd = self.load_monthly_limit()
        self._build_ui()
        self._start_emergency_listener()
        write_log("app_started", version=APP_VERSION)
        self.after(2500, lambda: self.check_for_updates(silent=True))

    def _build_ui(self) -> None:
        header = tk.Frame(self, bg="#20231f", padx=24, pady=20)
        header.pack(fill="x")
        tk.Label(header, text="PC Agent", fg="white", bg="#20231f", font=("Segoe UI", 21, "bold")).pack(anchor="w")
        tk.Label(
            header,
            text="브라우저와 Windows 프로그램을 함께 조작하는 통합 로컬 에이전트",
            fg="#c9cec5",
            bg="#20231f",
            font=("Segoe UI", 10),
        ).pack(anchor="w", pady=(3, 0))

        controls = tk.Frame(self, bg="#f4f2ed", padx=24, pady=18)
        controls.pack(fill="x")
        button_specs = [
            ("전체 점검", self.run_checks),
            ("일반 Chrome 연결", self.setup_normal_chrome),
            ("Chrome 열기", self.open_chrome),
            ("화면 캡처", self.capture_screen),
            ("ChatGPT 로그인", self.connect_chatgpt),
            ("연결 테스트", self.test_openai),
            ("즉시 중지", self.emergency_stop),
            ("중지 해제", self.clear_emergency_stop),
            ("이전 작업 재개", self.resume_last_task),
            ("다운로드 폴더", self.open_downloads),
            ("업데이트 확인", self.check_for_updates),
        ]
        for index, (text, command) in enumerate(button_specs):
            button = tk.Button(
                controls,
                text=text,
                command=command,
                relief="flat",
                padx=15,
                pady=9,
                bg="#d7d1c5" if text != "즉시 중지" else "#b84a3a",
                fg="#191b18" if text != "즉시 중지" else "white",
                activebackground="#c7c0b3",
                font=("Segoe UI", 10, "bold"),
            )
            button.grid(row=index // 3, column=index % 3, padx=(0, 9), pady=(0, 9), sticky="ew")
        for column in range(3):
            controls.grid_columnconfigure(column, weight=1)

        tk.Label(
            self,
            text="긴급 중지 단축키: Ctrl + Alt + Q   |   마우스를 화면 왼쪽 위 모서리로 이동해도 자동화가 중단됩니다.",
            bg="#f4f2ed",
            fg="#6c5f4d",
            font=("Segoe UI", 9),
        ).pack(anchor="w", padx=24)

        chat_options = tk.Frame(self, bg="#f4f2ed", padx=24)
        chat_options.pack(fill="x", pady=(12, 0))
        tk.Label(chat_options, text="AI 모델", bg="#f4f2ed", fg="#343a34", font=("Segoe UI", 9, "bold")).pack(side="left")
        self.model_name = tk.StringVar(value="절약형 · GPT-6 Luna")
        self.model_picker = ttk.Combobox(
            chat_options,
            textvariable=self.model_name,
            values=list(MODEL_OPTIONS),
            state="readonly",
            width=24,
        )
        self.model_picker.pack(side="left", padx=(8, 14))
        self.model_picker.bind("<<ComboboxSelected>>", lambda _event: self.reset_conversation(silent=True))
        self.usage_label = tk.Label(chat_options, text="ChatGPT 연결 확인 중", bg="#f4f2ed", fg="#6c5f4d", font=("Segoe UI", 9))
        self.usage_label.pack(side="left")
        tk.Button(
            chat_options,
            text="사용량 보기",
            command=self.open_plan_usage,
            relief="flat",
            bg="#e5e0d7",
            fg="#343a34",
        ).pack(side="right", padx=(8, 0))
        tk.Button(
            chat_options,
            text="연결 해제",
            command=self.disconnect_chatgpt,
            relief="flat",
            bg="#e5e0d7",
            fg="#343a34",
        ).pack(side="right", padx=(8, 0))
        tk.Button(
            chat_options,
            text="대화 초기화",
            command=self.reset_conversation,
            relief="flat",
            bg="#e5e0d7",
            fg="#343a34",
        ).pack(side="right")

        command_area = tk.Frame(self, bg="#f4f2ed", padx=24)
        command_area.pack(fill="x", pady=(8, 0))
        self.command_entry = tk.Entry(
            command_area,
            font=("Segoe UI", 11),
            relief="flat",
            bg="#fffefb",
            fg="#20231f",
        )
        self.command_entry.pack(side="left", fill="x", expand=True, ipady=10)
        self.command_entry.insert(0, "예: 네이버를 열어줘 / 오늘 할 일을 정리해줘")
        self.command_entry.bind("<Return>", lambda _event: self.run_chat())
        tk.Button(
            command_area,
            text="전송",
            command=self.run_chat,
            relief="flat",
            padx=18,
            pady=10,
            bg="#343a34",
            fg="white",
            font=("Segoe UI", 10, "bold"),
        ).pack(side="left", padx=(10, 0))

        self.output = scrolledtext.ScrolledText(
            self,
            wrap="word",
            font=("Consolas", 10),
            bg="#fffefb",
            fg="#20231f",
            relief="flat",
            padx=14,
            pady=14,
        )
        self.output.pack(fill="both", expand=True, padx=24, pady=(12, 24))
        self.say("준비됨. 아래 입력창에서 GPT와 대화하거나 PC 작업을 요청할 수 있습니다.")
        self.refresh_usage_label()
        if self.plan_auth.is_signed_in():
            self.say(f"ChatGPT 플랜 연결됨: {self.plan_auth.account_label()}")
        else:
            self.say("처음 한 번 ‘ChatGPT 로그인’을 눌러 구독 플랜을 연결해주세요.")
        pending = self.load_last_task()
        if pending and pending.get("status") in {"running", "stopped", "failed"}:
            self.say(f"재개 가능한 이전 작업: {pending.get('command', '')}")

    def say(self, text: str) -> None:
        self.output.insert("end", f"[{datetime.now().strftime('%H:%M:%S')}] {text}\n")
        self.output.see("end")
        self.update_idletasks()

    def run_checks(self) -> None:
        self.say("환경 점검을 시작합니다.")
        checks = {
            "운영체제": f"{platform.system()} {platform.release()}",
            "Python": sys.version.split()[0],
            "화면크기": f"{pyautogui.size().width} x {pyautogui.size().height}",
            "Chrome": find_chrome() or "찾지 못함",
            "ChatGPT 플랜": f"연결됨 ({self.plan_auth.account_label()})" if self.plan_auth.is_signed_in() else "로그인 필요",
            "API 키 과금": "차단됨 (ChatGPT 플랜만 사용)",
            "일반 Chrome": "연결됨" if self.chrome_bridge.is_connected() else "확장프로그램 연결 대기",
        }
        for name, value in checks.items():
            self.say(f"{name}: {value}")
        write_log("system_check", checks=checks)
        self.capture_screen(silent=True)
        self.say("점검 완료. 화면 캡처도 정상적으로 저장했습니다.")

    def capture_screen(self, silent: bool = False) -> None:
        path = SHOTS / f"screen_{timestamp()}.png"
        try:
            ImageGrab.grab(all_screens=True).save(path)
            write_log("screenshot", path=str(path))
            if not silent:
                self.say(f"화면 캡처 저장: {path}")
        except Exception as exc:
            write_log("screenshot_error", error=repr(exc))
            self.say(f"화면 캡처 실패: {exc}")

    def open_chrome(self) -> None:
        self.send_browser("open", "about:blank")

    def setup_normal_chrome(self) -> None:
        if self.chrome_bridge.is_connected():
            self.say("일반 Chrome 연결됨. 현재 로그인된 Chrome 탭을 사용할 수 있습니다.")
            return
        extension_path = str(CHROME_EXTENSION.resolve())
        pyperclip.copy(extension_path)
        chrome = find_chrome()
        if chrome:
            subprocess.Popen([chrome, "chrome://extensions/"])
        if os.name == "nt":
            os.startfile(CHROME_EXTENSION)
        self.say("일반 Chrome 연결 폴더 경로를 복사했고 확장프로그램 설정 화면을 열었습니다.")
        self.say("개발자 모드 → 압축해제된 확장 프로그램 로드 → 방금 열린 chrome-extension 폴더 선택")
        self.say("한 번 추가하면 이후에는 일반 Chrome의 기존 로그인 상태를 그대로 사용합니다.")

    def ensure_browser_worker(self) -> None:
        if self.browser_thread and self.browser_thread.is_alive():
            return
        self.browser_thread = threading.Thread(target=self._browser_worker, daemon=True)
        self.browser_thread.start()

    def send_browser(self, action: str, value: str) -> None:
        if self.chrome_bridge.is_connected():
            threading.Thread(
                target=self._extension_browser_action,
                args=(action, value),
                daemon=True,
            ).start()
            return
        self.say("일반 Chrome이 아직 연결되지 않았습니다.")
        self.say("Chrome 오른쪽 위 확장 프로그램(퍼즐) → 'Seunghyun PC Agent 연결'을 한 번 눌러 깨운 뒤 다시 실행해주세요.")
        write_log("normal_chrome_not_connected", action=action)

    def _extension_browser_action(self, action: str, value: str) -> None:
        try:
            if action == "open":
                self.chrome_bridge.request("navigate", url=value)
                self.after(0, lambda: self.say("일반 Chrome에서 페이지를 열었습니다."))
            elif action == "search":
                task = json.loads(value)
                self.chrome_bridge.request("navigate", url=task["url"])
                self._run_extension_agent({"goal": f"{task['query']} 검색", "model": MODEL_OPTIONS[self.model_name.get()]})
            elif action == "agent":
                self._run_extension_agent(json.loads(value))
            else:
                raise RuntimeError("Unsupported normal Chrome action")
        except Exception as exc:
            error_name = type(exc).__name__
            write_log("extension_browser_error", action=action, error_type=error_name, error_message=str(exc)[:500])
            self.after(0, lambda e=error_name: self.say(f"일반 Chrome 작업 실패: {e}. 확장프로그램 연결 상태를 확인해주세요."))

    def _run_extension_agent(self, task: dict) -> None:
        goal = str(task.get("goal") or "").strip()
        start_url = str(task.get("url") or "").strip()
        model = str(task.get("model") or "gpt-6-luna")
        if start_url.startswith("https://"):
            self.chrome_bridge.request("navigate", url=start_url)
        self.after(0, lambda: self.say(f"일반 Chrome 작업 시작: {goal}"))
        history: list[dict] = []
        visual_requested = False
        last_error = ""

        for step in range(1, 21):
            if STOP_EVENT.is_set():
                self.save_task(goal, "stopped", "emergency_stop")
                return
            usage = self.load_usage()
            if self.billing_mode() == "api_key" and usage["estimated_cost_usd"] >= self.monthly_limit_usd:
                self.save_task(goal, "stopped", "monthly_limit")
                self.after(0, lambda: self.say("월 API 사용 한도에 도달해 작업을 중단했습니다."))
                return
            observed = self.chrome_bridge.request("observe")
            elements = list(observed.get("elements") or [])
            state = {
                "goal": goal,
                "step": step,
                "url": str(observed.get("url") or ""),
                "title": str(observed.get("title") or ""),
                "elements": elements,
                "recent_history": history[-6:],
                "last_error": last_error,
            }
            visual_mode = visual_requested or not elements
            if visual_mode:
                visual = self.chrome_bridge.request("screenshot")
                image_url = str(visual.get("image_url") or "")
                state["image_width"] = int(visual.get("width") or 1)
                state["image_height"] = int(visual.get("height") or 1)
                response = self.create_response(
                    model=model,
                    timeout=45.0,
                    instructions=(
                        "You control the user's normal Chrome browser. Use the screenshot and DOM candidates together. "
                        "Recognize hamburger/three-dot menus, icon controls, dropdowns, tabs, dialogs, autocomplete and editors. "
                        "Return one JSON object with keys action, element_id, x, y, value, url, reason. action must be click, "
                        "hover, fill, select, upload, press, navigate, visual_click, scroll, done, or fail. Prefer element_id; "
                        "use visual_click only when the target has no reliable DOM candidate. Never purchase, pay, transfer money, "
                        "delete an account, or perform destructive deletion. Choose exactly one next action."
                    ),
                    input=[{"role": "user", "content": [
                        {"type": "input_text", "text": json.dumps(state, ensure_ascii=False)},
                        {"type": "input_image", "image_url": image_url},
                    ]}],
                )
            else:
                response = self.create_response(
                    model=model,
                    timeout=45.0,
                    instructions=(
                        "You control the user's normal Chrome browser from visible DOM candidates. Return one JSON object with "
                        "keys action, element_id, value, url, reason. action must be click, hover, fill, select, upload, press, "
                        "navigate, inspect_visual, done, or fail. Use only a supplied element_id. Recognize common website menus, "
                        "icon buttons, dropdowns, tabs, dialogs, autocomplete and rich-text editors from names, roles, class hints, "
                        "position and size. Use inspect_visual only when DOM clues are insufficient. Never purchase, pay, transfer "
                        "money, delete an account, or perform destructive deletion. Choose exactly one next action."
                    ),
                    input=json.dumps(state, ensure_ascii=False),
                )
            self.record_usage(
                model,
                int(getattr(response.usage, "input_tokens", 0) or 0),
                int(getattr(response.usage, "output_tokens", 0) or 0),
                str(getattr(response, "billing_mode", "api_key")),
            )
            self.after(0, self.refresh_usage_label)
            raw = response.output_text.strip()
            plan = json.loads(re.sub(r"^```(?:json)?\s*|\s*```$", "", raw, flags=re.IGNORECASE))
            next_action = str(plan.get("action") or "fail")
            element_id = str(plan.get("element_id") or "")
            reason = str(plan.get("reason") or next_action)
            self.after(0, lambda s=step, r=reason: self.say(f"일반 Chrome {s}단계: {r}"))
            write_log("extension_agent_step", step=step, action=next_action, reason=reason, url=state["url"])

            if next_action == "done":
                self.save_task(goal, "completed", state["url"])
                self.after(0, lambda u=state["url"]: self.say(f"일반 Chrome 작업 완료: {u}"))
                return
            if next_action == "fail":
                break
            if next_action == "inspect_visual":
                visual_requested = True
                last_error = "DOM 정보만으로 대상을 확실히 식별하지 못함"
                history.append({"step": step, "action": next_action, "result": "visual_requested"})
                continue
            try:
                if next_action in {"click", "hover", "fill", "select", "upload", "press"}:
                    if not re.fullmatch(r"pca-\d+", element_id):
                        raise RuntimeError("Invalid element id")
                    chosen = next((item for item in elements if item.get("id") == element_id), {})
                    label = " ".join(str(chosen.get(key) or "") for key in ("text", "ariaLabel", "title"))
                    if next_action == "click" and any(word in label for word in ("결제", "구매", "송금", "탈퇴", "삭제")):
                        raise RuntimeError("Sensitive final action blocked")
                self.chrome_bridge.request(
                    "act",
                    action=next_action,
                    element_id=element_id,
                    value=str(plan.get("value") or ""),
                    url=str(plan.get("url") or ""),
                    x=float(plan.get("x") or 0),
                    y=float(plan.get("y") or 0),
                    image_width=int(state.get("image_width") or 1),
                    image_height=int(state.get("image_height") or 1),
                )
                history.append({"step": step, "action": next_action, "reason": reason, "result": "ok"})
                last_error = ""
                visual_requested = False
            except Exception as step_exc:
                last_error = f"{type(step_exc).__name__}: {str(step_exc)[:240]}"
                history.append({"step": step, "action": next_action, "result": "failed", "error": last_error})
                visual_requested = True
                write_log("extension_agent_step_error", step=step, action=next_action, error_message=str(step_exc)[:500])
            time.sleep(0.7)

        final_state = self.chrome_bridge.request("observe")
        self.save_task(goal, "failed", str(final_state.get("url") or ""))
        self.after(0, lambda: self.say("일반 Chrome 작업을 완료하지 못했습니다. 마지막 화면 상태를 기록했습니다."))

    def _browser_worker(self) -> None:
        try:
            with sync_playwright() as pw:
                context = pw.chromium.launch_persistent_context(
                    user_data_dir=str(PROFILE / "playwright"),
                    headless=False,
                    viewport={"width": 1280, "height": 850},
                    accept_downloads=True,
                    downloads_path=str(DOWNLOADS),
                )
                page = context.pages[0] if context.pages else context.new_page()
                self.after(0, lambda: self.say("자동화 전용 브라우저가 준비되었습니다."))
                while not STOP_EVENT.is_set():
                    try:
                        action, value = self.browser_queue.get(timeout=0.25)
                    except queue.Empty:
                        continue
                    try:
                        if action == "open":
                            page.goto(value, wait_until="domcontentloaded", timeout=30000)
                        elif action == "search":
                            task = json.loads(value)
                            page.goto(task["url"], wait_until="domcontentloaded", timeout=30000)
                            selectors = [
                                "input[name='query']",
                                "textarea[name='q']",
                                "input[name='q']",
                                "input[type='search']",
                            ]
                            search_box = None
                            for selector in selectors:
                                candidate = page.locator(selector).first
                                if candidate.count() and candidate.is_visible():
                                    search_box = candidate
                                    break
                            if search_box is None:
                                raise RuntimeError("Search input not found")
                            search_box.fill(task["query"])
                            search_box.press("Enter")
                            page.wait_for_load_state("domcontentloaded", timeout=30000)
                        elif action == "agent":
                            page = self._run_web_agent(page, json.loads(value))
                        title = page.title()
                        shot = SHOTS / f"browser_{timestamp()}.png"
                        page.screenshot(path=str(shot), full_page=False)
                        write_log("browser_action_ok", action=action, url=page.url, title=title, screenshot=str(shot))
                        self.after(0, lambda u=page.url, t=title: self.say(f"브라우저 작업 완료: {t} | {u}"))
                    except Exception as action_exc:
                        error_name = type(action_exc).__name__
                        write_log(
                            "browser_action_error",
                            action=action,
                            error_type=error_name,
                            error_message=str(action_exc)[:500],
                        )
                        self.after(0, lambda e=error_name: self.say(f"브라우저 작업 실패: {e}. 화면을 캡처해서 보내주세요."))
                context.close()
        except Exception as exc:
            safe_error = type(exc).__name__
            write_log("browser_error", error_type=safe_error)
            self.after(0, lambda: self.say(f"브라우저 제어 실패: {safe_error}. 화면을 캡처해서 보내주세요."))

    def _page_elements(self, page) -> list[dict]:
        return page.evaluate(
            """() => {
                document.querySelectorAll('[data-pca-id]').forEach(el => el.removeAttribute('data-pca-id'));
                const candidates = [];
                const nativeSelector = [
                    'a', 'button', 'input', 'textarea', 'select', 'summary',
                    '[role="button"]', '[role="link"]', '[role="menuitem"]',
                    '[role="tab"]', '[role="option"]', '[contenteditable="true"]',
                    '[onclick]', '[aria-controls]', '[aria-expanded]',
                    '[tabindex]:not([tabindex="-1"])'
                ].join(',');
                for (const el of Array.from(document.querySelectorAll('body *'))) {
                    const rect = el.getBoundingClientRect();
                    const style = getComputedStyle(el);
                    if (rect.width < 3 || rect.height < 3 || style.visibility === 'hidden' || style.display === 'none') continue;
                    if (Number(style.opacity || 1) < 0.05) continue;
                    if (rect.bottom < 0 || rect.right < 0 || rect.top > innerHeight || rect.left > innerWidth) continue;
                    const isNative = el.matches(nativeSelector);
                    const pointer = style.cursor === 'pointer';
                    const hasAccessibleName = el.hasAttribute('aria-label') || el.hasAttribute('title');
                    const iconLike = Boolean(el.querySelector(':scope > svg, :scope > i, :scope > img')) && rect.width <= 160 && rect.height <= 160;
                    if (!isNative && !pointer && !hasAccessibleName && !iconLike) continue;
                    let score = isNative ? 5 : 0;
                    if (hasAccessibleName) score += 3;
                    if (pointer) score += 2;
                    if (iconLike) score += 2;
                    if (el.hasAttribute('aria-expanded') || el.hasAttribute('aria-controls')) score += 3;
                    const hint = `${el.id || ''} ${typeof el.className === 'string' ? el.className : ''} ${el.getAttribute('aria-label') || ''}`.toLowerCase();
                    if (/menu|nav|hamburger|drawer|gnb|toggle|more/.test(hint)) score += 4;
                    if (iconLike && rect.top < 180 && rect.left > innerWidth * 0.6) score += 3;
                    candidates.push({el, rect, style, score});
                }
                candidates.sort((a, b) => b.score - a.score || a.rect.top - b.rect.top || a.rect.left - b.rect.left);
                const result = [];
                for (const item of candidates.slice(0, 180)) {
                    const {el, rect, style} = item;
                    const id = `pca-${result.length}`;
                    el.setAttribute('data-pca-id', id);
                    const type = (el.getAttribute('type') || '').toLowerCase();
                    const className = typeof el.className === 'string' ? el.className : '';
                    result.push({
                        id,
                        tag: el.tagName.toLowerCase(),
                        type,
                        text: (el.innerText || el.getAttribute('aria-label') || el.getAttribute('title') || '').trim().slice(0, 160),
                        label: el.labels ? Array.from(el.labels).map(x => x.innerText.trim()).join(' | ').slice(0, 160) : '',
                        name: (el.getAttribute('name') || '').slice(0, 80),
                        placeholder: (el.getAttribute('placeholder') || '').slice(0, 120),
                        href: el.tagName === 'A' ? (el.href || '').slice(0, 300) : '',
                        ariaLabel: (el.getAttribute('aria-label') || '').slice(0, 120),
                        ariaExpanded: el.getAttribute('aria-expanded') || '',
                        ariaControls: (el.getAttribute('aria-controls') || '').slice(0, 100),
                        title: (el.getAttribute('title') || '').slice(0, 120),
                        domId: (el.id || '').slice(0, 100),
                        classHint: className.slice(0, 140),
                        cursor: style.cursor,
                        x: Math.round(rect.left),
                        y: Math.round(rect.top),
                        width: Math.round(rect.width),
                        height: Math.round(rect.height),
                        checked: type === 'checkbox' || type === 'radio' ? Boolean(el.checked) : undefined
                    });
                }
                return result;
            }"""
        )

    def _browser_screenshot_payload(self, page) -> tuple[str, int, int]:
        screenshot_bytes = page.screenshot(type="jpeg", quality=72, full_page=False)
        with Image.open(io.BytesIO(screenshot_bytes)) as screenshot:
            width, height = screenshot.size
        image_url = "data:image/jpeg;base64," + base64.b64encode(screenshot_bytes).decode("ascii")
        return image_url, width, height

    def _run_web_agent(self, page, task: dict):
        goal = str(task.get("goal") or "").strip()
        start_url = str(task.get("url") or "").strip()
        model = str(task.get("model") or "gpt-6-luna")
        if start_url.startswith("https://"):
            page.goto(start_url, wait_until="domcontentloaded", timeout=30000)
        self.after(0, lambda: self.say(f"웹 작업 시작: {goal}"))
        completed = False
        history: list[dict] = []
        visual_requested = False
        last_error = ""

        for step in range(1, 21):
            if STOP_EVENT.is_set():
                self.after(0, lambda: self.say("웹 작업이 긴급 중지되었습니다."))
                self.save_task(goal, "stopped", page.url)
                return page
            usage = self.load_usage()
            if self.billing_mode() == "api_key" and usage["estimated_cost_usd"] >= self.monthly_limit_usd:
                self.after(0, lambda: self.say("월 API 사용 한도에 도달해 웹 작업을 중단했습니다."))
                self.save_task(goal, "stopped", "monthly_limit")
                return page
            elements = self._page_elements(page)
            state = {
                "goal": goal,
                "step": step,
                "url": page.url,
                "title": page.title(),
                "elements": elements,
                "recent_history": history[-6:],
                "last_error": last_error,
            }
            visual_mode = visual_requested or not elements
            if visual_mode:
                image_url, image_width, image_height = self._browser_screenshot_payload(page)
                state["image_width"] = image_width
                state["image_height"] = image_height
                response = self.create_response(
                    model=model,
                    timeout=40.0,
                    instructions=(
                        "You are a general browser-control agent. Use the screenshot together with the visible DOM candidates. "
                        "Recognize common website patterns including hamburger/three-line/three-dot menus, icon-only controls, "
                        "drop-down navigation, tabs, dialogs, autocomplete, and hover menus. Return one JSON object with keys "
                        "action, element_id, x, y, value, url, reason. action must be click, hover, fill, select, upload, press, "
                        "navigate, visual_click, scroll, done, or fail. Prefer a supplied element_id when it identifies the target; "
                        "otherwise use visual_click with screenshot-pixel coordinates. Never purchase, pay, transfer money, delete "
                        "an account, or perform destructive deletion. Choose one next action and re-observe after it."
                    ),
                    input=[{"role": "user", "content": [
                        {"type": "input_text", "text": json.dumps(state, ensure_ascii=False)},
                        {"type": "input_image", "image_url": image_url},
                    ]}],
                )
            else:
                response = self.create_response(
                    model=model,
                    timeout=40.0,
                    instructions=(
                        "You are a general browser-control agent using visible DOM candidates. Return one JSON object. "
                        "Keys: action, element_id, value, url, reason. action must be click, hover, fill, select, upload, press, navigate, done, or fail. "
                        "It may also be inspect_visual when the correct control cannot be identified reliably from DOM data. "
                        "Use only an element_id present in the list. fill puts value into an input. select chooses a visible label/value. "
                        "upload sets a local file path on a file input. press uses a key such as Enter. navigate allows only https. "
                        "Recognize standard patterns such as hamburger menus, three-dot menus, icon buttons, dropdowns, tabs, dialogs, "
                        "autocomplete and hover navigation from aria fields, class hints, position and size. Ask for inspect_visual only "
                        "when those clues are insufficient. Never purchase, pay, transfer money, delete an account, or perform destructive "
                        "deletion. Choose one next action. Use done only when the goal is visibly complete."
                    ),
                    input=json.dumps(state, ensure_ascii=False),
                )
            input_tokens = int(getattr(response.usage, "input_tokens", 0) or 0)
            output_tokens = int(getattr(response.usage, "output_tokens", 0) or 0)
            self.record_usage(model, input_tokens, output_tokens, str(getattr(response, "billing_mode", "api_key")))
            self.after(0, self.refresh_usage_label)
            raw = response.output_text.strip()
            cleaned = re.sub(r"^```(?:json)?\s*|\s*```$", "", raw, flags=re.IGNORECASE)
            plan = json.loads(cleaned)
            next_action = str(plan.get("action") or "fail")
            element_id = str(plan.get("element_id") or "")
            value = str(plan.get("value") or "")
            reason = str(plan.get("reason") or next_action)
            write_log("web_agent_step", step=step, action=next_action, reason=reason, url=page.url)
            self.after(0, lambda s=step, r=reason: self.say(f"웹 작업 {s}단계: {r}"))

            if next_action == "done":
                completed = True
                break
            if next_action == "fail":
                break
            if next_action == "inspect_visual":
                visual_requested = True
                last_error = "DOM 정보만으로 대상을 확실히 식별하지 못해 화면 확인이 필요함"
                history.append({"step": step, "action": next_action, "result": "visual_requested"})
                continue
            try:
                if next_action == "navigate":
                    target_url = str(plan.get("url") or "")
                    if not target_url.startswith("https://"):
                        raise RuntimeError("Unsafe navigation URL")
                    page.goto(target_url, wait_until="domcontentloaded", timeout=30000)
                elif next_action == "visual_click" and visual_mode:
                    viewport = page.viewport_size or {"width": image_width, "height": image_height}
                    click_x = float(plan.get("x") or 0) * viewport["width"] / max(image_width, 1)
                    click_y = float(plan.get("y") or 0) * viewport["height"] / max(image_height, 1)
                    page.mouse.click(click_x, click_y)
                elif next_action == "scroll" and visual_mode:
                    page.mouse.wheel(0, float(plan.get("value") or 650))
                else:
                    if not re.fullmatch(r"pca-\d+", element_id):
                        raise RuntimeError("Invalid element id")
                    target = page.locator(f'[data-pca-id="{element_id}"]').first
                    if target.count() == 0:
                        raise RuntimeError("Element disappeared")
                    if next_action == "click":
                        label = target.evaluate(
                            "el => (el.innerText || el.getAttribute('aria-label') || el.getAttribute('title') || '').trim()"
                        )
                        if any(word in label for word in ("결제", "구매", "송금", "탈퇴", "삭제")):
                            raise RuntimeError("Sensitive final action blocked")
                        try:
                            target.scroll_into_view_if_needed(timeout=3000)
                        except Exception:
                            pass
                        try:
                            target.click(timeout=5000)
                        except Exception:
                            href = target.evaluate("el => el.href || ''")
                            if href.startswith("https://") or href.startswith("http://"):
                                page.goto(href, wait_until="domcontentloaded", timeout=30000)
                            else:
                                target.evaluate("el => el.click()")
                    elif next_action == "hover":
                        try:
                            target.scroll_into_view_if_needed(timeout=3000)
                        except Exception:
                            pass
                        target.hover(timeout=5000, force=True)
                    elif next_action == "fill":
                        target.fill(value, timeout=15000)
                    elif next_action == "select":
                        try:
                            target.select_option(label=value, timeout=15000)
                        except Exception:
                            target.select_option(value=value, timeout=15000)
                    elif next_action == "upload":
                        upload_path = Path(value).expanduser().resolve()
                        if not upload_path.is_file():
                            raise RuntimeError("Upload file not found")
                        target.set_input_files(str(upload_path), timeout=15000)
                    elif next_action == "press":
                        target.press(value or "Enter", timeout=15000)
                    else:
                        raise RuntimeError("Unsupported browser action")
                last_error = ""
                visual_requested = False
                history.append({"step": step, "action": next_action, "reason": reason, "result": "ok"})
            except Exception as step_exc:
                last_error = f"{type(step_exc).__name__}: {str(step_exc)[:240]}"
                visual_requested = True
                history.append({"step": step, "action": next_action, "reason": reason, "result": "failed", "error": last_error})
                write_log(
                    "web_agent_step_error",
                    step=step,
                    action=next_action,
                    element_id=element_id,
                    error_type=type(step_exc).__name__,
                    error_message=str(step_exc)[:500],
                )
                self.after(0, lambda s=step: self.say(f"웹 작업 {s}단계가 막혀 화면을 확인한 뒤 다른 방법으로 계속합니다."))
            page.wait_for_timeout(700)
            if page.context.pages:
                page = page.context.pages[-1]
            try:
                page.wait_for_load_state("domcontentloaded", timeout=5000)
            except Exception:
                pass

        shot = SHOTS / f"agent_{timestamp()}.png"
        page.screenshot(path=str(shot), full_page=False)
        final_title = page.title()
        final_url = page.url
        if completed:
            self.save_task(goal, "completed", final_url)
            self.after(0, lambda t=final_title, u=final_url: self.say(f"웹 작업 완료: {t} | {u}"))
        else:
            self.save_task(goal, "failed", final_url)
            self.after(0, lambda: self.say("웹 작업을 완료하지 못했습니다. 현재 화면을 캡처해 기록했습니다."))
        return page

    def run_chat(self) -> None:
        command = self.command_entry.get().strip()
        if not command or command.startswith("예:"):
            self.say("실행할 명령을 입력해주세요.")
            return
        if self.billing_mode() == "none":
            self.say("먼저 ‘ChatGPT 로그인’을 눌러 구독 플랜을 연결해주세요.")
            return
        usage = self.load_usage()
        if self.billing_mode() == "api_key" and usage["estimated_cost_usd"] >= self.monthly_limit_usd:
            self.say(f"월 사용 한도 ${self.monthly_limit_usd:.2f}에 도달해 요청을 중단했습니다.")
            return
        self.command_entry.delete(0, "end")
        self.say(f"나: {command}")
        self.say("GPT가 답변을 작성하고 있습니다...")
        STOP_EVENT.clear()
        self.save_task(command, "running", "planning")
        requested_model = MODEL_OPTIONS[self.model_name.get()]

        def worker() -> None:
            try:
                if self.available_models is None:
                    self.available_models = self.available_model_ids()
                model = requested_model if requested_model in self.available_models else None
                if not model:
                    preferred = ["gpt-6-luna", "gpt-6.1-sol", "gpt-6-sol", "gpt-5.4-mini", "gpt-5.4"]
                    model = next((name for name in preferred if name in self.available_models), None)
                if not model:
                    raise RuntimeError("No compatible GPT model")
                request = {
                    "model": model,
                    "instructions": (
                        "You are the Korean assistant and browser planner inside Seunghyun PC Agent. "
                        "Return only a single valid JSON object with keys reply, action, url, query. "
                        "action must be one of chat, open, search, agent, native. For ordinary conversation use chat and empty url/query. "
                        "For opening a site use open with its official https URL. For searching, use search with the official "
                        "search engine homepage URL and the exact search phrase. For clicking links, filling forms, selecting options, "
                        "or a multi-step web task use agent; put the full goal in query and an https start URL in url when known, "
                        "otherwise leave url empty to continue on the currently open page. Use native for Windows desktop programs, "
                        "File Explorer, Hangul, Excel, Word, or other non-browser PC actions; put the full goal in query. "
                        "reply must be a concise Korean response."
                    ),
                    "input": command,
                }
                if self.billing_mode() == "api_key" and self.previous_response_id and self.previous_model == model:
                    request["previous_response_id"] = self.previous_response_id
                response = self.create_response(timeout=45.0, **request)
                if self.billing_mode() == "api_key":
                    self.previous_response_id = response.id
                    self.previous_model = model
                raw_answer = response.output_text.strip()
                cleaned = re.sub(r"^```(?:json)?\s*|\s*```$", "", raw_answer, flags=re.IGNORECASE)
                try:
                    plan = json.loads(cleaned)
                except json.JSONDecodeError:
                    plan = {"reply": raw_answer, "action": "chat", "url": "", "query": ""}
                visible_answer = str(plan.get("reply") or "처리했습니다.")
                action = str(plan.get("action") or "chat")
                action_url = str(plan.get("url") or "")
                search_query = str(plan.get("query") or "")
                valid_open = action in {"open", "search"} and action_url.startswith("https://")
                input_tokens = int(getattr(response.usage, "input_tokens", 0) or 0)
                output_tokens = int(getattr(response.usage, "output_tokens", 0) or 0)
                billing_mode = str(getattr(response, "billing_mode", "api_key"))
                cost = self.record_usage(model, input_tokens, output_tokens, billing_mode)
                write_log(
                    "chat_response",
                    model=model,
                    billing_mode=billing_mode,
                    input_tokens=input_tokens,
                    output_tokens=output_tokens,
                    estimated_cost_usd=cost,
                    browser_action=action if valid_open else "none",
                )
                self.after(0, lambda a=visible_answer or "처리했습니다.": self.say(f"GPT: {a}"))
                self.after(0, self.refresh_usage_label)
                if valid_open and action == "open":
                    self.send_browser("open", action_url.rstrip(".,)"))
                elif valid_open and action == "search" and search_query:
                    self.send_browser("search", json.dumps({"url": action_url, "query": search_query}, ensure_ascii=False))
                elif action == "agent":
                    self.send_browser(
                        "agent",
                        json.dumps(
                            {"goal": search_query or command, "url": action_url, "model": model},
                            ensure_ascii=False,
                        ),
                    )
                elif action == "native":
                    threading.Thread(
                        target=self._run_native_agent_safe,
                        args=(search_query or command, model),
                        daemon=True,
                    ).start()
                else:
                    self.save_task(command, "completed", "chat")
            except Exception as exc:
                safe_error = type(exc).__name__
                error_code = str(getattr(exc, "code", "") or "")
                error_param = str(getattr(exc, "param", "") or "")
                request_id = str(getattr(exc, "request_id", "") or "")
                write_log(
                    "chat_error",
                    error_type=safe_error,
                    error_code=error_code,
                    error_param=error_param,
                    request_id=request_id,
                    message=str(exc)[:1000],
                )
                self.save_task(command, "failed", safe_error)
                message = self.explain_openai_error(exc)
                self.after(0, lambda m=message: self.say(m))

        threading.Thread(target=worker, daemon=True).start()

    def _run_native_agent_safe(self, goal: str, model: str) -> None:
        try:
            self._run_native_agent(goal, model)
        except Exception as exc:
            error_name = type(exc).__name__
            write_log("native_agent_error", error_type=error_name)
            self.save_task(goal, "failed", error_name)
            self.after(0, lambda e=error_name: self.say(f"Windows 작업 실패: {e}. 화면과 로그를 확인해주세요."))

    def _desktop_screenshot_payload(self) -> tuple[str, int, int, int, int]:
        original = ImageGrab.grab(all_screens=True)
        source_width, source_height = original.size
        preview = original.copy()
        preview.thumbnail((1280, 800), Image.Resampling.LANCZOS)
        buffer = io.BytesIO()
        preview.save(buffer, format="JPEG", quality=78)
        encoded = base64.b64encode(buffer.getvalue()).decode("ascii")
        return f"data:image/jpeg;base64,{encoded}", source_width, source_height, preview.width, preview.height

    def _run_native_agent(self, goal: str, model: str) -> None:
        self.after(0, lambda: self.say(f"Windows 작업 시작: {goal}"))
        app_commands = {
            "notepad": ["notepad.exe"],
            "calculator": ["calc.exe"],
            "explorer": ["explorer.exe"],
            "chrome": [find_chrome() or "chrome.exe"],
            "excel": ["excel.exe"],
            "word": ["winword.exe"],
            "powerpoint": ["powerpnt.exe"],
            "hangul": ["hwp.exe"],
        }
        for step in range(1, 13):
            if STOP_EVENT.is_set():
                self.save_task(goal, "stopped", "emergency_stop")
                return
            image_url, sw, sh, pw, ph = self._desktop_screenshot_payload()
            response = self.create_response(
                model=model,
                timeout=45.0,
                instructions=(
                    "You control a Windows desktop from a screenshot. Return only one JSON object with keys "
                    "action, x, y, text, keys, app, reason. action must be click, double_click, type, hotkey, "
                    "press, open_app, wait, done, or fail. Screenshot coordinates use the supplied image pixels. "
                    "For type, click the field in a prior step, then return type with text. keys is an array for hotkey. "
                    "Supported app names: notepad, calculator, explorer, chrome, excel, word, powerpoint, hangul. "
                    "Never perform purchases, payments, transfers, account deletion, or destructive deletion. "
                    "Choose one action only and use done when the visible result satisfies the goal."
                ),
                input=[{
                    "role": "user",
                    "content": [
                        {"type": "input_text", "text": json.dumps({"goal": goal, "step": step, "image_width": pw, "image_height": ph}, ensure_ascii=False)},
                        {"type": "input_image", "image_url": image_url},
                    ],
                }],
            )
            self.record_usage(
                model,
                int(getattr(response.usage, "input_tokens", 0) or 0),
                int(getattr(response.usage, "output_tokens", 0) or 0),
                str(getattr(response, "billing_mode", "api_key")),
            )
            self.after(0, self.refresh_usage_label)
            raw = response.output_text.strip()
            plan = json.loads(re.sub(r"^```(?:json)?\s*|\s*```$", "", raw, flags=re.IGNORECASE))
            action = str(plan.get("action") or "fail")
            reason = str(plan.get("reason") or action)
            self.after(0, lambda s=step, r=reason: self.say(f"Windows 작업 {s}단계: {r}"))
            write_log("native_agent_step", step=step, action=action, reason=reason)
            if action == "done":
                self.save_task(goal, "completed", reason)
                self.after(0, lambda: self.say("Windows 작업을 완료했습니다."))
                return
            if action == "fail":
                break
            x = int(float(plan.get("x") or 0) * sw / max(pw, 1))
            y = int(float(plan.get("y") or 0) * sh / max(ph, 1))
            if action == "click":
                pyautogui.click(x, y)
            elif action == "double_click":
                pyautogui.doubleClick(x, y, interval=0.15)
            elif action == "type":
                pyperclip.copy(str(plan.get("text") or ""))
                pyautogui.hotkey("ctrl", "v")
            elif action == "hotkey":
                keys = [str(k).lower() for k in (plan.get("keys") or [])]
                if not keys:
                    raise RuntimeError("Missing hotkey")
                pyautogui.hotkey(*keys)
            elif action == "press":
                pyautogui.press(str(plan.get("text") or "enter").lower())
            elif action == "open_app":
                app_name = str(plan.get("app") or "").lower()
                if app_name not in app_commands:
                    raise RuntimeError("Unsupported application")
                subprocess.Popen(app_commands[app_name])
            elif action != "wait":
                raise RuntimeError("Unsupported native action")
            time.sleep(1.2)
        self.save_task(goal, "failed", "step_limit_or_model_failure")
        self.after(0, lambda: self.say("Windows 작업을 완료하지 못했습니다. 마지막 화면과 로그를 확인해주세요."))

    def save_task(self, command: str, status: str, detail: str = "") -> None:
        TASK_FILE.write_text(
            json.dumps(
                {"command": command, "status": status, "detail": detail, "updated_at": datetime.now().isoformat(timespec="seconds")},
                ensure_ascii=False,
                indent=2,
            ),
            encoding="utf-8",
        )

    def load_last_task(self) -> dict | None:
        try:
            return json.loads(TASK_FILE.read_text(encoding="utf-8"))
        except (FileNotFoundError, json.JSONDecodeError, OSError):
            return None

    def resume_last_task(self) -> None:
        task = self.load_last_task()
        if not task or not task.get("command"):
            self.say("재개할 이전 작업이 없습니다.")
            return
        self.command_entry.delete(0, "end")
        self.command_entry.insert(0, str(task["command"]))
        self.run_chat()

    def clear_emergency_stop(self) -> None:
        STOP_EVENT.clear()
        self.say("긴급 중지 상태를 해제했습니다.")

    def open_downloads(self) -> None:
        if os.name == "nt":
            os.startfile(DOWNLOADS)
        else:
            subprocess.Popen(["xdg-open", str(DOWNLOADS)])

    def check_for_updates(self, silent: bool = False) -> None:
        if self.update_busy:
            if not silent:
                self.say("이미 업데이트를 확인하고 있습니다.")
            return
        self.update_busy = True
        if not silent:
            self.say("새 버전을 확인하고 있습니다...")

        def worker() -> None:
            try:
                info = self.update_client.check()
                write_log("update_check_ok", available=bool(info), version=info.version if info else APP_VERSION)
                self.after(0, lambda i=info, s=silent: self._finish_update_check(i, s))
            except Exception as exc:
                write_log("update_check_error", error_type=type(exc).__name__, message=str(exc)[:500])
                self.after(0, lambda e=exc, s=silent: self._finish_update_error(e, s))

        threading.Thread(target=worker, daemon=True).start()

    def _finish_update_check(self, info: UpdateInfo | None, silent: bool) -> None:
        self.update_busy = False
        if info is None:
            if not silent:
                self.say(f"현재 {APP_VERSION}이 최신 버전입니다.")
            return
        notes = f"\n\n{info.notes}" if info.notes else ""
        install_now = messagebox.askyesno(
            "PC Agent 업데이트",
            f"새 버전 {info.version}이 있습니다.{notes}\n\n지금 자동으로 업데이트할까요?",
            parent=self,
        )
        if install_now:
            self.install_update(info)
        elif not silent:
            self.say(f"{info.version} 업데이트를 나중에 진행합니다.")

    def _finish_update_error(self, exc: Exception, silent: bool) -> None:
        self.update_busy = False
        if not silent:
            self.say(f"업데이트 확인 실패: {type(exc).__name__}. 인터넷 연결 후 다시 시도해주세요.")

    def install_update(self, info: UpdateInfo) -> None:
        if self.update_busy:
            return
        self.update_busy = True
        self.say(f"{info.version} 업데이트를 다운로드하고 검증하고 있습니다...")

        def worker() -> None:
            try:
                package = self.update_client.download(info)
                write_log("update_download_ok", version=info.version, package=str(package))
                self.after(0, lambda p=package, i=info: self._apply_update(p, i))
            except Exception as exc:
                write_log("update_download_error", error_type=type(exc).__name__, message=str(exc)[:500])
                self.after(0, lambda e=exc: self._finish_update_error(e, False))

        threading.Thread(target=worker, daemon=True).start()

    def _apply_update(self, package: Path, info: UpdateInfo) -> None:
        try:
            self.say("검증 완료. 프로그램을 재시작하여 업데이트를 적용합니다.")
            launch_installer(package, ROOT, info.version)
            self.after(300, self.destroy)
        except Exception as exc:
            self.update_busy = False
            write_log("update_launch_error", error_type=type(exc).__name__, message=str(exc)[:500])
            self.say(f"업데이트 실행 실패: {type(exc).__name__}. 프로그램은 기존 버전으로 계속 사용할 수 있습니다.")

    def reset_conversation(self, silent: bool = False) -> None:
        self.previous_response_id = None
        self.previous_model = None
        if not silent:
            self.say("새 대화를 시작합니다.")

    def billing_mode(self) -> str:
        if self.plan_auth.is_signed_in():
            return "chatgpt_plan"
        if os.getenv("PC_AGENT_ALLOW_API_FALLBACK") == "1" and self.get_api_key():
            return "api_key"
        return "none"

    def available_model_ids(self) -> set[str]:
        if self.plan_auth.is_signed_in():
            models = self.plan_auth.list_models()
            return {str(item.get("slug") or item.get("id") or "") for item in models if item.get("slug") or item.get("id")}
        api_key = self.get_api_key()
        if not api_key:
            return set()
        client = OpenAI(api_key=api_key, timeout=20.0)
        return {item.id for item in client.models.list().data}

    def create_response(self, *, model: str, timeout: float = 45.0, **request):
        mode = self.billing_mode()
        if mode == "none":
            raise PlanAuthError("먼저 ChatGPT로 로그인해주세요.", "not_signed_in")
        if mode == "api_key":
            response = OpenAI(api_key=self.get_api_key(), timeout=timeout).responses.create(model=model, **request)
            return SimpleNamespace(
                id=str(getattr(response, "id", "") or ""),
                output_text=str(getattr(response, "output_text", "") or ""),
                usage=getattr(response, "usage", None) or SimpleNamespace(input_tokens=0, output_tokens=0),
                billing_mode=mode,
            )

        access_token = self.plan_auth.get_access_token()
        # The ChatGPT-plan sharing contract documents all prompt content inside
        # `input`. Normalize plan requests to that supported request surface.
        plan_instructions = str(request.pop("instructions", "") or "").strip()
        if plan_instructions:
            plan_input = request.get("input", "")
            if isinstance(plan_input, str):
                request["input"] = [{
                    "role": "user",
                    "content": f"{plan_instructions}\n\nTASK OR STATE:\n{plan_input}",
                }]
            elif isinstance(plan_input, list) and plan_input:
                first = plan_input[0]
                if isinstance(first, dict):
                    content = first.get("content", "")
                    if isinstance(content, str):
                        first["content"] = f"{plan_instructions}\n\nTASK OR STATE:\n{content}"
                    elif isinstance(content, list):
                        first["content"] = [
                            {"type": "input_text", "text": plan_instructions},
                            *content,
                        ]
            else:
                request["input"] = [{"role": "user", "content": plan_instructions}]
        client = OpenAI(
            api_key=access_token,
            base_url="https://api.openai.com/v1",
            timeout=timeout,
            max_retries=0,
        )
        request.pop("previous_response_id", None)
        text_parts: list[str] = []
        completed_response = None
        failure_code = "response_failed"
        with client.responses.create(
            model=model,
            store=False,
            stream=True,
            **request,
        ) as stream:
            for event in stream:
                event_type = str(getattr(event, "type", ""))
                if event_type == "response.output_text.delta":
                    text_parts.append(str(getattr(event, "delta", "")))
                elif event_type == "response.failed":
                    failed_response = getattr(event, "response", None)
                    error = getattr(failed_response, "error", None)
                    failure_code = str(getattr(error, "code", "") or failure_code)
                    raise PlanAuthError("ChatGPT 플랜 요청이 실패했습니다.", failure_code)
                elif event_type == "response.completed":
                    completed_response = getattr(event, "response", None)
        if completed_response is None:
            raise PlanAuthError("응답 스트림이 완료되지 않았습니다.", "incomplete_stream")
        output_text = "".join(text_parts) or str(getattr(completed_response, "output_text", "") or "")
        usage = getattr(completed_response, "usage", None) or SimpleNamespace(input_tokens=0, output_tokens=0)
        return SimpleNamespace(
            id=str(getattr(completed_response, "id", "") or ""),
            output_text=output_text,
            usage=usage,
            billing_mode=mode,
        )

    def explain_openai_error(self, exc: Exception) -> str:
        text = f"{getattr(exc, 'code', '')} {str(exc)}".lower()
        if "subscription_sharing_usage_limit_exceeded" in text:
            return "ChatGPT 플랜 또는 PC Agent의 사용 한도에 도달했습니다. ‘사용량 보기’에서 확인해주세요."
        if "not_signed_in" in text or "먼저 chatgpt" in text:
            return "먼저 ‘ChatGPT 로그인’을 눌러 구독 플랜을 연결해주세요."
        if "invalid_grant" in text or "invalid_user" in text or "token" in text:
            return "ChatGPT 연결이 만료되었습니다. ‘ChatGPT 로그인’을 다시 눌러주세요."
        code = str(getattr(exc, "code", "") or "").strip()
        param = str(getattr(exc, "param", "") or "").strip()
        detail = "/".join(item for item in (code, param) if item)
        if detail:
            return f"GPT 처리 실패: {type(exc).__name__} ({detail}). 화면을 캡처해서 보내주세요."
        return f"GPT 처리 실패: {type(exc).__name__}. 화면을 캡처해서 보내주세요."

    def load_usage(self) -> dict:
        month = datetime.now().strftime("%Y-%m")
        empty = {
            "month": month,
            "input_tokens": 0,
            "output_tokens": 0,
            "estimated_cost_usd": 0.0,
            "plan_requests": 0,
            "plan_input_tokens": 0,
            "plan_output_tokens": 0,
        }
        try:
            saved = json.loads(USAGE_FILE.read_text(encoding="utf-8"))
            return {**empty, **saved} if saved.get("month") == month else empty
        except (FileNotFoundError, json.JSONDecodeError, OSError):
            return empty

    def record_usage(self, model: str, input_tokens: int, output_tokens: int, billing_mode: str = "api_key") -> float:
        usage = self.load_usage()
        if billing_mode == "chatgpt_plan":
            usage["plan_requests"] += 1
            usage["plan_input_tokens"] += input_tokens
            usage["plan_output_tokens"] += output_tokens
            USAGE_FILE.write_text(json.dumps(usage, ensure_ascii=False, indent=2), encoding="utf-8")
            return 0.0
        prices = MODEL_PRICES.get(model, MODEL_PRICES["gpt-6.1-sol"])
        added = input_tokens / 1_000_000 * prices["input"] + output_tokens / 1_000_000 * prices["output"]
        usage["input_tokens"] += input_tokens
        usage["output_tokens"] += output_tokens
        usage["estimated_cost_usd"] = round(float(usage["estimated_cost_usd"]) + added, 8)
        USAGE_FILE.write_text(json.dumps(usage, ensure_ascii=False, indent=2), encoding="utf-8")
        return added

    def refresh_usage_label(self) -> None:
        usage = self.load_usage()
        mode = self.billing_mode()
        if mode == "chatgpt_plan":
            self.usage_label.config(text=f"ChatGPT 구독 사용 중 · 이번 달 요청 {usage['plan_requests']}회")
        elif mode == "api_key":
            self.usage_label.config(
                text=f"API 예비 사용료: ${usage['estimated_cost_usd']:.4f} / 한도 ${self.monthly_limit_usd:.2f}"
            )
        else:
            self.usage_label.config(text="ChatGPT 로그인 필요")

    def set_monthly_limit(self) -> None:
        value = simpledialog.askfloat(
            "월 API 사용 한도",
            "이번 달 최대 사용 금액(USD)을 입력하세요.",
            initialvalue=self.monthly_limit_usd,
            minvalue=0.10,
            maxvalue=1000.0,
            parent=self,
        )
        if value is None:
            return
        self.monthly_limit_usd = float(value)
        SETTINGS_FILE.write_text(
            json.dumps({"monthly_limit_usd": self.monthly_limit_usd}, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )
        self.refresh_usage_label()
        self.say(f"월 API 사용 한도를 ${self.monthly_limit_usd:.2f}로 설정했습니다.")

    def load_monthly_limit(self) -> float:
        try:
            saved = json.loads(SETTINGS_FILE.read_text(encoding="utf-8"))
            return max(0.10, float(saved.get("monthly_limit_usd", 10.0)))
        except (FileNotFoundError, json.JSONDecodeError, OSError, TypeError, ValueError):
            return 10.0

    def get_api_key(self) -> str | None:
        return os.getenv("OPENAI_API_KEY") or keyring.get_password(KEYRING_SERVICE, KEYRING_USER)

    def connect_chatgpt(self) -> None:
        if self.plan_auth.is_signed_in():
            self.say(f"이미 ChatGPT 플랜에 연결되어 있습니다: {self.plan_auth.account_label()}")
            self.test_openai()
            return
        self.say("웹브라우저에서 ChatGPT 로그인을 완료하고 PC Agent 사용 권한을 승인해주세요.")

        def worker() -> None:
            try:
                record = self.plan_auth.sign_in()
                self.available_models = None
                self.previous_response_id = None
                write_log("chatgpt_plan_connected", account=str(record.get("email") or "connected"))
                self.after(0, self.refresh_usage_label)
                self.after(
                    0,
                    lambda: self.say(
                        f"ChatGPT 구독 플랜 연결 완료: {record.get('email') or '계정 확인됨'}. 이제 API 키 과금 없이 플랜 사용량을 우선 사용합니다."
                    ),
                )
                self.after(0, self.test_openai)
            except Exception as exc:
                code = str(getattr(exc, "code", "") or "")
                write_log("chatgpt_plan_login_error", error_type=type(exc).__name__, error_code=code)
                message = self.explain_openai_error(exc)
                self.after(0, lambda m=message: self.say(m))

        threading.Thread(target=worker, daemon=True).start()

    def disconnect_chatgpt(self) -> None:
        if not self.plan_auth.is_signed_in():
            self.say("연결된 ChatGPT 계정이 없습니다.")
            return
        if not messagebox.askyesno(
            "ChatGPT 연결 해제",
            "이 PC에 저장된 ChatGPT 로그인 토큰을 삭제할까요?\nChatGPT 설정에서 앱 권한을 별도로 취소할 수도 있습니다.",
            parent=self,
        ):
            return
        self.plan_auth.sign_out()
        self.available_models = None
        self.reset_conversation(silent=True)
        self.refresh_usage_label()
        write_log("chatgpt_plan_disconnected")
        self.say("이 PC의 ChatGPT 연결 정보를 삭제했습니다.")

    def open_plan_usage(self) -> None:
        webbrowser.open("https://chatgpt.com/#settings/usage", new=1)
        self.say("ChatGPT 설정의 사용량 화면을 열었습니다. 여기서 PC Agent 한도와 남은 사용량을 확인할 수 있습니다.")

    def setup_openai(self) -> None:
        value = simpledialog.askstring(
            "OpenAI API 키 설정",
            "OpenAI Platform에서 만든 API 키를 붙여 넣으세요.\n키는 화면과 로그에 저장되지 않고 Windows 보안 저장소에 보관됩니다.",
            show="*",
            parent=self,
        )
        if value is None:
            return
        value = value.strip()
        if not value.startswith("sk-") or len(value) < 30:
            messagebox.showerror("키 형식 오류", "OpenAI API 키 형식이 올바르지 않습니다.")
            return
        keyring.set_password(KEYRING_SERVICE, KEYRING_USER, value)
        write_log("api_key_saved", storage="windows_keyring")
        self.say("OpenAI API 키를 Windows 보안 저장소에 저장했습니다.")
        self.test_openai()

    def test_openai(self) -> None:
        if self.billing_mode() == "none":
            self.say("ChatGPT 연결이 없습니다. 먼저 ‘ChatGPT 로그인’을 눌러주세요.")
            return
        self.say("ChatGPT 플랜 연결을 확인하고 있습니다..." if self.plan_auth.is_signed_in() else "OpenAI API 연결을 확인하고 있습니다...")

        def worker() -> None:
            try:
                models = self.available_model_ids()
                count = len(models)
                self.available_models = models
                mode = self.billing_mode()
                write_log("openai_connection_ok", billing_mode=mode, visible_models=count)
                if mode == "chatgpt_plan":
                    self.after(0, lambda: self.say(f"ChatGPT 구독 플랜 연결 성공. 사용 가능한 모델 {count}개를 확인했습니다."))
                else:
                    self.after(0, lambda: self.say(f"OpenAI API 예비 연결 성공. 사용 가능한 모델 {count}개를 확인했습니다."))
            except Exception as exc:
                safe_error = type(exc).__name__
                code = str(getattr(exc, "code", "") or "")
                write_log("openai_connection_error", error_type=safe_error, error_code=code)
                message = self.explain_openai_error(exc)
                self.after(0, lambda m=message: self.say(m))

        threading.Thread(target=worker, daemon=True).start()

    def emergency_stop(self) -> None:
        STOP_EVENT.set()
        write_log("emergency_stop")
        self.say("긴급 중지 신호가 설정되었습니다. 진행 중인 자동화를 중단합니다.")

    def _start_emergency_listener(self) -> None:
        pressed: set[keyboard.Key | keyboard.KeyCode] = set()

        def on_press(key):
            pressed.add(key)
            q_pressed = any(getattr(k, "char", "") == "q" for k in pressed)
            if keyboard.Key.ctrl_l in pressed or keyboard.Key.ctrl_r in pressed:
                if keyboard.Key.alt_l in pressed or keyboard.Key.alt_r in pressed:
                    if q_pressed:
                        self.after(0, self.emergency_stop)

        def on_release(key):
            pressed.discard(key)

        listener = keyboard.Listener(on_press=on_press, on_release=on_release)
        listener.daemon = True
        listener.start()


if __name__ == "__main__":
    AgentApp().mainloop()

