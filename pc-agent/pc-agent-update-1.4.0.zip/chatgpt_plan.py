from __future__ import annotations

import base64
import hashlib
import json
import secrets
import threading
import time
import uuid
import webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.error import HTTPError, URLError
from urllib.parse import parse_qs, urlencode, urlparse
from urllib.request import Request, urlopen

import jwt
import keyring
from cryptography.fernet import Fernet, InvalidToken


AUTHORIZATION_ENDPOINT = "https://auth.openai.com/api/accounts/authorize"
TOKEN_ENDPOINT = "https://auth.openai.com/api/accounts/oauth/token"
DISCOVERY_ENDPOINT = "https://auth.openai.com/.well-known/openid-configuration"
API_RESOURCE = "https://api.openai.com/v1"
REQUIRED_SCOPE = "chatgpt.tokens.use.direct"
SCOPES = "openid profile email offline_access resource.invoke chatgpt.tokens.use.direct"
KEYRING_SERVICE = "SeunghyunPCAgent.ChatGPTPlan"
KEYRING_USER = "credential_encryption_key"


class PlanAuthError(RuntimeError):
    def __init__(self, message: str, code: str = "plan_auth_error") -> None:
        super().__init__(message)
        self.code = code


def _base64url(raw: bytes) -> str:
    return base64.urlsafe_b64encode(raw).rstrip(b"=").decode("ascii")


def _json_request(url: str, *, token: str | None = None, timeout: float = 30.0) -> dict:
    headers = {"Accept": "application/json", "User-Agent": "Seunghyun-PC-Agent/1.4.0"}
    if token:
        headers["Authorization"] = f"Bearer {token}"
    request = Request(url, headers=headers)
    try:
        with urlopen(request, timeout=timeout) as response:
            return json.loads(response.read().decode("utf-8"))
    except HTTPError as exc:
        body = exc.read().decode("utf-8", errors="replace")
        try:
            payload = json.loads(body)
            error = payload.get("error") or {}
            code = str(error.get("code") or error.get("type") or f"http_{exc.code}")
            message = str(error.get("message") or code)
        except (json.JSONDecodeError, AttributeError):
            code = f"http_{exc.code}"
            message = code
        raise PlanAuthError(message, code) from exc
    except URLError as exc:
        raise PlanAuthError("OpenAI 로그인 서버에 연결할 수 없습니다.", "network_error") from exc


def _post_form(url: str, values: dict[str, str], timeout: float = 30.0) -> dict:
    request = Request(
        url,
        data=urlencode(values).encode("utf-8"),
        headers={
            "Accept": "application/json",
            "Content-Type": "application/x-www-form-urlencoded",
            "User-Agent": "Seunghyun-PC-Agent/1.4.0",
        },
        method="POST",
    )
    try:
        with urlopen(request, timeout=timeout) as response:
            return json.loads(response.read().decode("utf-8"))
    except HTTPError as exc:
        body = exc.read().decode("utf-8", errors="replace")
        try:
            payload = json.loads(body)
            error = payload.get("error")
            if isinstance(error, dict):
                code = str(error.get("code") or error.get("type") or f"http_{exc.code}")
                message = str(error.get("message") or code)
            else:
                code = str(error or f"http_{exc.code}")
                message = str(payload.get("error_description") or code)
        except json.JSONDecodeError:
            code = f"http_{exc.code}"
            message = code
        raise PlanAuthError(message, code) from exc
    except URLError as exc:
        raise PlanAuthError("OpenAI 로그인 서버에 연결할 수 없습니다.", "network_error") from exc


class ChatGPTPlanAuth:
    def __init__(self, data_dir: Path, app_name: str = "Seunghyun PC Agent") -> None:
        self.data_dir = data_dir
        self.app_name = app_name
        self.config_path = data_dir / "chatgpt_plan_config.json"
        self.credential_path = data_dir / "chatgpt_plan_credentials.bin"
        self._refresh_lock = threading.Lock()
        self.host_id = self._load_or_create_host_id()

    def _load_or_create_host_id(self) -> str:
        try:
            payload = json.loads(self.config_path.read_text(encoding="utf-8"))
            value = str(payload.get("ext_agent_host_id") or "")
            if value.startswith("urn:uuid:"):
                return value
        except (FileNotFoundError, json.JSONDecodeError, OSError):
            pass
        value = f"urn:uuid:{uuid.uuid4()}"
        self.config_path.write_text(
            json.dumps({"ext_agent_host_id": value}, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )
        try:
            self.config_path.chmod(0o600)
        except OSError:
            pass
        return value

    def load_record(self) -> dict | None:
        try:
            key = keyring.get_password(KEYRING_SERVICE, KEYRING_USER)
            if not key or not self.credential_path.is_file():
                return None
            decrypted = Fernet(key.encode("ascii")).decrypt(self.credential_path.read_bytes())
            return json.loads(decrypted.decode("utf-8"))
        except (json.JSONDecodeError, OSError, InvalidToken, ValueError):
            return None

    def _save_record(self, record: dict) -> None:
        key = keyring.get_password(KEYRING_SERVICE, KEYRING_USER)
        if not key:
            key = Fernet.generate_key().decode("ascii")
            keyring.set_password(KEYRING_SERVICE, KEYRING_USER, key)
        encrypted = Fernet(key.encode("ascii")).encrypt(json.dumps(record, ensure_ascii=False).encode("utf-8"))
        temporary = self.credential_path.with_suffix(".tmp")
        temporary.write_bytes(encrypted)
        try:
            temporary.chmod(0o600)
        except OSError:
            pass
        temporary.replace(self.credential_path)

    def sign_out(self) -> None:
        try:
            self.credential_path.unlink(missing_ok=True)
        except OSError:
            pass
        try:
            keyring.delete_password(KEYRING_SERVICE, KEYRING_USER)
        except keyring.errors.PasswordDeleteError:
            pass

    def is_signed_in(self) -> bool:
        record = self.load_record()
        return bool(record and record.get("refresh_token") and REQUIRED_SCOPE in record.get("scopes", []))

    def account_label(self) -> str:
        record = self.load_record() or {}
        return str(record.get("email") or "ChatGPT 계정")

    def _validate_id_token(self, id_token: str, client_id: str, nonce: str) -> dict:
        discovery = _json_request(DISCOVERY_ENDPOINT)
        jwks_uri = str(discovery.get("jwks_uri") or "")
        issuer = str(discovery.get("issuer") or "https://auth.openai.com")
        if not jwks_uri:
            raise PlanAuthError("OpenAI 공개키 주소를 확인할 수 없습니다.", "missing_jwks_uri")
        signing_key = jwt.PyJWKClient(jwks_uri).get_signing_key_from_jwt(id_token)
        claims = jwt.decode(
            id_token,
            signing_key.key,
            algorithms=["RS256"],
            audience=client_id,
            issuer=issuer,
        )
        if claims.get("nonce") != nonce:
            raise PlanAuthError("로그인 검증값이 일치하지 않습니다.", "invalid_nonce")
        return dict(claims)

    def sign_in(self, timeout: float = 240.0) -> dict:
        existing = self.load_record() or {}
        state = secrets.token_urlsafe(32)
        nonce = secrets.token_urlsafe(32)
        verifier = secrets.token_urlsafe(64)
        challenge = _base64url(hashlib.sha256(verifier.encode("ascii")).digest())
        callback_result: dict[str, str] = {}
        callback_event = threading.Event()

        class CallbackHandler(BaseHTTPRequestHandler):
            def log_message(self, _format, *_args) -> None:
                return

            def do_GET(self) -> None:
                parsed = urlparse(self.path)
                if parsed.path != "/auth/callback":
                    self.send_error(404)
                    return
                values = parse_qs(parsed.query)
                for key in ("code", "state", "client_id", "scope", "error", "error_description"):
                    if values.get(key):
                        callback_result[key] = values[key][0]
                ok = callback_result.get("state") == state and "code" in callback_result
                title = "ChatGPT 연결 완료" if ok else "ChatGPT 연결 실패"
                message = "PC Agent로 돌아가세요. 이 창은 닫아도 됩니다." if ok else "PC Agent에서 다시 로그인을 시도해주세요."
                body = (
                    "<!doctype html><meta charset='utf-8'><title>" + title + "</title>"
                    "<body style='font-family:sans-serif;padding:48px;background:#f7f7f5'>"
                    f"<h1>{title}</h1><p>{message}</p></body>"
                ).encode("utf-8")
                self.send_response(200)
                self.send_header("Content-Type", "text/html; charset=utf-8")
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)
                callback_event.set()

        server = ThreadingHTTPServer(("127.0.0.1", 0), CallbackHandler)
        port = int(server.server_address[1])
        redirect_uri = f"http://127.0.0.1:{port}/auth/callback"
        server_thread = threading.Thread(target=server.serve_forever, daemon=True)
        server_thread.start()

        issued_client_id = str(existing.get("client_id") or "")
        client_id = issued_client_id or "dynamic_agent_client"
        params = {
            "client_id": client_id,
            "response_type": "code",
            "redirect_uri": redirect_uri,
            "scope": SCOPES,
            "resource": API_RESOURCE,
            "state": state,
            "nonce": nonce,
            "code_challenge_method": "S256",
            "code_challenge": challenge,
            "ext_agent_host_id": self.host_id,
        }
        if not issued_client_id:
            params["agent_name_hint"] = self.app_name

        try:
            webbrowser.open(f"{AUTHORIZATION_ENDPOINT}?{urlencode(params)}", new=1)
            if not callback_event.wait(timeout):
                raise PlanAuthError("로그인 시간이 초과되었습니다.", "login_timeout")
        finally:
            server.shutdown()
            server.server_close()

        if callback_result.get("state") != state:
            raise PlanAuthError("로그인 요청 검증에 실패했습니다.", "invalid_state")
        if callback_result.get("error"):
            raise PlanAuthError(
                callback_result.get("error_description") or "ChatGPT 연결이 취소되었습니다.",
                callback_result["error"],
            )
        code = callback_result.get("code")
        returned_client_id = callback_result.get("client_id")
        if not code:
            raise PlanAuthError("로그인 코드가 반환되지 않았습니다.", "missing_code")
        if issued_client_id:
            if returned_client_id and returned_client_id != issued_client_id:
                raise PlanAuthError("등록된 계정과 다른 로그인 결과입니다.", "client_id_mismatch")
            exchange_client_id = issued_client_id
        else:
            if not returned_client_id or returned_client_id == "dynamic_agent_client":
                raise PlanAuthError("PC Agent 등록이 완료되지 않았습니다.", "missing_issued_client_id")
            exchange_client_id = returned_client_id

        token = _post_form(
            TOKEN_ENDPOINT,
            {
                "grant_type": "authorization_code",
                "code": code,
                "redirect_uri": redirect_uri,
                "client_id": exchange_client_id,
                "code_verifier": verifier,
                "resource": API_RESOURCE,
            },
        )
        id_token = str(token.get("id_token") or "")
        if not id_token:
            raise PlanAuthError("ID 토큰이 반환되지 않았습니다.", "missing_id_token")
        claims = self._validate_id_token(id_token, exchange_client_id, nonce)
        scopes = str(token.get("scope") or callback_result.get("scope") or "").split()
        if REQUIRED_SCOPE not in scopes:
            raise PlanAuthError("ChatGPT 플랜 사용 권한이 승인되지 않았습니다.", "plan_scope_not_granted")
        if issued_client_id and existing.get("subject") and claims.get("sub") != existing.get("subject"):
            raise PlanAuthError("기존에 연결한 ChatGPT 계정과 다릅니다.", "account_mismatch")

        now = time.time()
        record = {
            "email": str(claims.get("email") or ""),
            "name": str(claims.get("name") or ""),
            "issuer": str(claims.get("iss") or "https://auth.openai.com"),
            "subject": str(claims.get("sub") or ""),
            "client_id": exchange_client_id,
            "ext_agent_host_id": self.host_id,
            "id_token": id_token,
            "access_token": str(token.get("access_token") or ""),
            "refresh_token": str(token.get("refresh_token") or ""),
            "token_type": str(token.get("token_type") or "Bearer"),
            "expires_in": int(token.get("expires_in") or 3600),
            "expires_at": now + int(token.get("expires_in") or 3600),
            "earliest_refresh_at": float(token.get("earliest_refresh_at") or 0),
            "scopes": scopes,
            "saved_at": now,
        }
        if not record["access_token"] or not record["refresh_token"]:
            raise PlanAuthError("로그인 토큰이 완전하지 않습니다.", "incomplete_token_response")
        self._save_record(record)
        return record

    def get_access_token(self) -> str:
        with self._refresh_lock:
            record = self.load_record()
            if not record:
                raise PlanAuthError("먼저 ChatGPT로 로그인해주세요.", "not_signed_in")
            now = time.time()
            if float(record.get("expires_at") or 0) > now + 120:
                return str(record["access_token"])
            earliest = float(record.get("earliest_refresh_at") or 0)
            if earliest > now and float(record.get("expires_at") or 0) > now:
                return str(record["access_token"])
            token = _post_form(
                TOKEN_ENDPOINT,
                {
                    "grant_type": "refresh_token",
                    "client_id": str(record.get("client_id") or ""),
                    "refresh_token": str(record.get("refresh_token") or ""),
                    "resource": API_RESOURCE,
                },
            )
            scopes = str(token.get("scope") or " ".join(record.get("scopes") or [])).split()
            if REQUIRED_SCOPE not in scopes:
                raise PlanAuthError("ChatGPT 플랜 권한이 만료되었습니다. 다시 로그인해주세요.", "plan_scope_not_granted")
            expires_in = int(token.get("expires_in") or 3600)
            updated = {
                **record,
                "access_token": str(token.get("access_token") or ""),
                "refresh_token": str(token.get("refresh_token") or ""),
                "token_type": str(token.get("token_type") or "Bearer"),
                "expires_in": expires_in,
                "expires_at": now + expires_in,
                "earliest_refresh_at": float(token.get("earliest_refresh_at") or 0),
                "scopes": scopes,
                "saved_at": now,
            }
            if token.get("id_token"):
                updated["id_token"] = str(token["id_token"])
            if not updated["access_token"] or not updated["refresh_token"]:
                raise PlanAuthError("토큰 갱신 응답이 완전하지 않습니다.", "incomplete_refresh_response")
            self._save_record(updated)
            return str(updated["access_token"])

    def list_models(self) -> list[dict]:
        payload = _json_request(f"{API_RESOURCE}/models", token=self.get_access_token())
        models = payload.get("models")
        if not isinstance(models, list):
            models = payload.get("data") if isinstance(payload.get("data"), list) else []
        return [item for item in models if isinstance(item, dict) and item.get("visibility", "list") == "list"]
